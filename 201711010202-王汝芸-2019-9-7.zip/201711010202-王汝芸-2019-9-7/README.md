# 算法分析与设计
## 第一次课程报告
**作业内容**
> 1. 穷举法  
2. 素数试除算法  
3. 挑战：大整数素数判断  
4. CAAIS练习洗牌算法&二分搜索算法  
5. 二分搜索算法  
6. 挑战：二分搜索算法递归版  

**系统环境**
> 系统：Windows10 专业版 1903  
> 语言：C++ 17  
> 编译器：MinGW-64W  
> 平台：CLion 2019.1.4  

**Github**  
https://github.com/RuYunW/AlgorithmAnalysisAndDesign/tree/master/作业1  

-----
ruyunw@163.com  
2019-9-7  
